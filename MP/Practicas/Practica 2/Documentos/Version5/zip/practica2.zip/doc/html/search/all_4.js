var searchData=
[
  ['getcentro',['getCentro',['../classCirculo.html#a022cde4d10d14a47a3b3921f80909f3b',1,'Circulo::getCentro() const '],['../classCirculo.html#a022cde4d10d14a47a3b3921f80909f3b',1,'Circulo::getCentro() const '],['../classCirculo.html#a022cde4d10d14a47a3b3921f80909f3b',1,'Circulo::getCentro() const ']]],
  ['getradio',['getRadio',['../classCirculo.html#a982f8a785d8a68ab1483b609cd752980',1,'Circulo::getRadio() const '],['../classCirculo.html#a982f8a785d8a68ab1483b609cd752980',1,'Circulo::getRadio() const '],['../classCirculo.html#a982f8a785d8a68ab1483b609cd752980',1,'Circulo::getRadio() const ']]],
  ['getx',['getX',['../classPunto.html#aa218292fec9bad5ec6d71d4bd9173d9d',1,'Punto::getX() const '],['../classPunto.html#aa218292fec9bad5ec6d71d4bd9173d9d',1,'Punto::getX() const '],['../classPunto.html#aa218292fec9bad5ec6d71d4bd9173d9d',1,'Punto::getX() const ']]],
  ['gety',['getY',['../classPunto.html#a214978b8bbae48ca5927f2e56fb3bd22',1,'Punto::getY() const '],['../classPunto.html#a214978b8bbae48ca5927f2e56fb3bd22',1,'Punto::getY() const '],['../classPunto.html#a214978b8bbae48ca5927f2e56fb3bd22',1,'Punto::getY() const ']]]
];
