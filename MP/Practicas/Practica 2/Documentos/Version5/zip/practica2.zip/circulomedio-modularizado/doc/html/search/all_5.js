var searchData=
[
  ['interior',['interior',['../circulo_8h.html#a6e60e1271c0a8f48e87f8e53b434dfd4',1,'interior(Punto p, Circulo c):&#160;circulo.cpp'],['../circulo_8cpp.html#a6e60e1271c0a8f48e87f8e53b434dfd4',1,'interior(Punto p, Circulo c):&#160;circulo.cpp']]]
];
